﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Exercise
{
    public partial class Form1 : Form
    {
        String operation;
        Double firstnum;
        Double secondnum;
        Double answer;
        Double iTax;

        Double Dosa;
        Double Idly;
        Double OtherItems;

        Double Nigerian_Naira = 302.96;
        Double US_Dollar = 1.52;
        Double Kenyan_Shilling = 156.21;
        Double Brazillian_Real = 5.86;
        Double Canadian_Dollar = 2.03;
        Double Indian_Rupee = 100.68;
        Double Phillipine_Peso = 71.74;
        Double Indonesia_Rupiah = 20746.75;
        public Form1()
        {
            InitializeComponent();
        }

        private void order_SystemsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.order_SystemsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.ordersDataSet1);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'ordersDataSet1.Order_Systems' table. You can move, or remove it, as needed.
            this.order_SystemsTableAdapter.Fill(this.ordersDataSet1.Order_Systems);
            cmbCurrency.Text = " Choose one....";
            cmbCurrency.Items.Add("USA");
            cmbCurrency.Items.Add("Nigeria");
            cmbCurrency.Items.Add("Kenyan");
            cmbCurrency.Items.Add("Canada");
            cmbCurrency.Items.Add("Brazil");
            cmbCurrency.Items.Add("India");
            cmbCurrency.Items.Add("Phillipine");
            cmbCurrency.Items.Add("Indonesia");

            DateTime iDate = DateTime.Now;

            order_DateTextBox.Text = iDate.ToString("d/M/y");
            order_TimeTextBox.Text = iDate.ToString("HH:mm:ss");

            qty1TextBox.Text = "0";
            qty2TextBox.Text = "0";
            qty3TextBox.Text = "0";

            unit_Price1TextBox.Text = "0";
            unit_Price2TextBox.Text = "0";
            unit_Price3TextBox.Text = "0";



        }

        private void unit_Price1TextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button_Click(object sender, EventArgs e)
        {
            Button num = (Button)sender;
            if (lblDisplay.Text == "0")
                lblDisplay.Text = num.Text;

            else
                lblDisplay.Text = lblDisplay.Text + num.Text;
        }

        private void Cal_Operators(object sender, EventArgs e)
        {
            Button ops = (Button)sender;
            firstnum = Double.Parse(lblDisplay.Text);
            lblDisplay.Text = "";
            operation = ops.Text;
            lblShowCal.Text = System.Convert.ToString(firstnum) + "" + operation;
        }

        private void BtnEqual_Click(object sender, EventArgs e)
        {
            lblShowCal.Text = "";
            secondnum = Double.Parse(lblDisplay.Text);
            switch (operation)
            {
                case "+":
                    answer = (firstnum + secondnum);
                    lblDisplay.Text = System.Convert.ToString(answer);
                    break;
                case "-":
                    answer = (firstnum - secondnum);
                    lblDisplay.Text = System.Convert.ToString(answer);
                    break;
                case "*":
                    answer = (firstnum * secondnum);
                    lblDisplay.Text = System.Convert.ToString(answer);
                    break;
                case "/":
                    answer = (firstnum / secondnum);
                    lblDisplay.Text = System.Convert.ToString(answer);
                    break;
                default:
                    break;


            }
        }

        private void BtnBspace_Click(object sender, EventArgs e)
        {
            if (lblDisplay.Text.Length > 0)
                lblDisplay.Text = lblDisplay.Text.Remove(lblDisplay.Text.Length - 1, 1);
        }

        private void BtnDot_Click(object sender, EventArgs e)
        {
            Button num = (Button)sender;
            if (num.Text == ".")
            {
                if (!lblDisplay.Text.Contains("."))
                    lblDisplay.Text = lblDisplay.Text + num.Text;
            }
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            lblDisplay.Text = "";
            lblShowCal.Text = "";
            lblDisplay.Text = "0";
        }

        private void currencyConvertorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BtnCurrencyConvertor.Visible = false;
        }

        private void BtnCurrencyConvertor_Click(object sender, EventArgs e)
        {
            BtnCurrencyConvertor.Visible = false;
        }

        private void standardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BtnCurrencyConvertor.Visible = true;
        }

        private void receiptToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void order_SystemsBindingNavigator_RefreshItems(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            DateTime iDate = DateTime.Now;

            order_DateTextBox.Text = iDate.ToString("d/M/y");
            order_TimeTextBox.Text = iDate.ToString("HH:mm:ss");



            tabControl1.SelectedTab = tabPage2;
            this.Validate();
            this.order_SystemsBindingSource.EndEdit();
        }

        private void BtnReset_Click(object sender, EventArgs e)
        {
            qty1TextBox.Text = "0";
            qty2TextBox.Text = "0";
            qty3TextBox.Text = "0";

            unit_Price1TextBox.Text = "0";
            unit_Price2TextBox.Text = "0";
            unit_Price3TextBox.Text = "0";

            sub_Total1TextBox.Text = "0";
            sub_Total2TextBox.Text = "0";
            sub_Total3TextBox.Text = "0";

            net_Sub_TotalTextBox.Text = "";
            taxTextBox.Text = "";
            net_TotalTextBox.Text = "";

            customer_NameTextBox.Text = "";
            customer_PhoneTextBox.Text = "";
            order_IdTextBox.Text = "";
        }

        private void BtnFavorites_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage2;
            txtReceipt.AppendText("\t\t\t" + "Cognulsoft Online Food Orders ");
            txtReceipt.AppendText("\t\t\t" + "==============================================================================================" + Environment.NewLine);
            txtReceipt.AppendText("" + Environment.NewLine);

            txtReceipt.AppendText("Name:" + "\t" + customer_NameTextBox.Text +"\t" +"Phone No:" + customer_PhoneTextBox.Text +"\t" + "Order Id:" + order_IdTextBox.Text + Environment.NewLine);
            txtReceipt.AppendText(Environment.NewLine +"Order_Date:" + "\t"+ order_DateTextBox.Text + "\t" + "Order_Time:" + order_TimeTextBox.Text + "\t" + "Order Id:"+ Environment.NewLine);
            txtReceipt.AppendText(Environment.NewLine + "\t" + "Item Type" + "\t" + "Qty:" + "Unit Price" + "\t" + "Sub Total" + Environment.NewLine);
            txtReceipt.AppendText(Environment.NewLine + "\t" + "Dosa" + "\t" + qty1TextBox.Text + unit_Price1TextBox.Text + "\t" + sub_Total1TextBox.Text + Environment.NewLine);
            txtReceipt.AppendText(Environment.NewLine + "\t" + "Idly" + "\t" + qty2TextBox.Text + unit_Price2TextBox.Text + "\t" + sub_Total2TextBox.Text + Environment.NewLine);
            txtReceipt.AppendText(Environment.NewLine + "\t" + "Other Items" + "\t" + qty3TextBox.Text + unit_Price3TextBox.Text + "\t" + sub_Total3TextBox.Text + Environment.NewLine);


            txtReceipt.AppendText(Environment.NewLine + "\t" + "Order Sub Total:" + "\t" + net_Sub_TotalTextBox.Text + Environment.NewLine);
            txtReceipt.AppendText(Environment.NewLine + "\t" + "Tax on Order:" + "\t" + taxTextBox.Text + Environment.NewLine);
            txtReceipt.AppendText(Environment.NewLine + "\t" + "Net Total:" + "\t" + net_TotalTextBox.Text + Environment.NewLine);

            txtReceipt.AppendText("" + "==============================================================================================" + Environment.NewLine);
            txtReceipt.AppendText("\t\t\t" + "Cognulsoft Online Food Orders"+Environment.NewLine);
        }

        private void BtnCalculator_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage1;
        }

        private void BtnOrder_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage3;
        }

        private void BtnReceipt_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage2;
        }

        private void BtnTotal_Click(object sender, EventArgs e)
        {
            Double DDosa;
            Double IIdly;
            Double OOtherItems;
            Double unitprice1;
            Double unitprice2;
            Double unitprice3;
            Double NetTax;
            Double SubTotal;
            Double NetTotal;

            DDosa = Double.Parse(qty1TextBox.Text);
            IIdly = Double.Parse(qty2TextBox.Text);
            OOtherItems = Double.Parse(qty3TextBox.Text);

            unitprice1 = Double.Parse(unit_Price1TextBox.Text);
            unitprice2 = Double.Parse(unit_Price2TextBox.Text);
            unitprice3 = Double.Parse(unit_Price3TextBox.Text);

            Dosa = DDosa * unitprice1;
            Idly = IIdly * unitprice2;
            OtherItems = OOtherItems * unitprice3;

            sub_Total1TextBox.Text = System.Convert.ToString(Dosa);
            sub_Total2TextBox.Text = System.Convert.ToString(Idly);
            sub_Total3TextBox.Text = System.Convert.ToString(OtherItems);

            net_Sub_TotalTextBox.Text = System.Convert.ToString(Dosa + Idly + OtherItems);
            NetTax = ((Dosa + Idly + OtherItems) * iTax) / 100;
            taxTextBox.Text = System.Convert.ToString(NetTax);
            net_TotalTextBox.Text = System.Convert.ToString(NetTax + (Dosa + Idly + OtherItems));

 
            unit_Price1TextBox.Text = String.Format("{0:C}", Double.Parse(unit_Price1TextBox.Text));
            unit_Price2TextBox.Text = String.Format("{0:C}", Double.Parse(unit_Price2TextBox.Text));
            unit_Price3TextBox.Text = String.Format("{0:C}", Double.Parse(unit_Price3TextBox.Text));

            sub_Total1TextBox.Text = String.Format("{0:C}", Double.Parse(sub_Total1TextBox.Text));
            sub_Total2TextBox.Text = String.Format("{0:C}", Double.Parse(sub_Total2TextBox.Text));
            sub_Total3TextBox.Text = String.Format("{0:C}", Double.Parse(sub_Total3TextBox.Text));

            net_Sub_TotalTextBox.Text = String.Format("{0:C}", Double.Parse(net_Sub_TotalTextBox.Text));
            taxTextBox.Text = String.Format("{0:C}", Double.Parse(taxTextBox.Text));
            net_TotalTextBox.Text = String.Format("{0:C}", Double.Parse(net_TotalTextBox.Text));

        }

        private void BtnConvert_Click(object sender, EventArgs e)
        {
            Double British_Pound = Double.Parse(txtConvert.Text);

            if (cmbCurrency.Text == "Nigeria")
            {
                lblConvert.Text = System.Convert.ToString((British_Pound * Nigerian_Naira));
            }
            if (cmbCurrency.Text == "Kenyan")
            {
                lblConvert.Text = System.Convert.ToString((British_Pound * Kenyan_Shilling));
            }
            if (cmbCurrency.Text == "USA")
            {
                lblConvert.Text = System.Convert.ToString((British_Pound * US_Dollar));
            }
            if (cmbCurrency.Text == "Canada")
            {
                lblConvert.Text = System.Convert.ToString((British_Pound * Canadian_Dollar));
            }
            if (cmbCurrency.Text == "Brazil")
            {
                lblConvert.Text = System.Convert.ToString((British_Pound * Brazillian_Real));
            }
            if (cmbCurrency.Text == "India")
            {
                lblConvert.Text = System.Convert.ToString((British_Pound * Indian_Rupee));
            }
            if (cmbCurrency.Text == "Phillipine")
            {
                lblConvert.Text = System.Convert.ToString((British_Pound * Phillipine_Peso));
            }
            if (cmbCurrency.Text == "Indonesia")
            {
                lblConvert.Text = System.Convert.ToString((British_Pound * Indonesia_Rupiah));
            }

        }
    }
}
