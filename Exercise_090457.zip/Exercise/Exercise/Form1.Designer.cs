﻿namespace Exercise
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.order_TimeTextBox = new System.Windows.Forms.TextBox();
            this.order_SystemsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ordersDataSet1 = new Exercise.OrdersDataSet1();
            this.order_DateTextBox = new System.Windows.Forms.TextBox();
            this.customer_PhoneTextBox = new System.Windows.Forms.TextBox();
            this.customer_NameTextBox = new System.Windows.Forms.TextBox();
            this.order_IdTextBox = new System.Windows.Forms.TextBox();
            this.lbltime = new System.Windows.Forms.Label();
            this.lbldate = new System.Windows.Forms.Label();
            this.lblorder = new System.Windows.Forms.Label();
            this.lblphone = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.BtnFavorites = new System.Windows.Forms.Button();
            this.BtnOrder = new System.Windows.Forms.Button();
            this.BtnReceipt = new System.Windows.Forms.Button();
            this.BtnCalculator = new System.Windows.Forms.Button();
            this.BtnSave = new System.Windows.Forms.Button();
            this.BtnReset = new System.Windows.Forms.Button();
            this.BtnTotal = new System.Windows.Forms.Button();
            this.sub_Total3TextBox = new System.Windows.Forms.TextBox();
            this.sub_Total2TextBox = new System.Windows.Forms.TextBox();
            this.sub_Total1TextBox = new System.Windows.Forms.TextBox();
            this.unit_Price3TextBox = new System.Windows.Forms.TextBox();
            this.unit_Price2TextBox = new System.Windows.Forms.TextBox();
            this.unit_Price1TextBox = new System.Windows.Forms.TextBox();
            this.qty3TextBox = new System.Windows.Forms.TextBox();
            this.qty2TextBox = new System.Windows.Forms.TextBox();
            this.qty1TextBox = new System.Windows.Forms.TextBox();
            this.lblotherfoods = new System.Windows.Forms.Label();
            this.lblidly = new System.Windows.Forms.Label();
            this.lbldosa = new System.Windows.Forms.Label();
            this.lblsubtotal = new System.Windows.Forms.Label();
            this.lblunitprice = new System.Windows.Forms.Label();
            this.lblqty = new System.Windows.Forms.Label();
            this.lblfoods = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.lblShowCal = new System.Windows.Forms.Label();
            this.BtnCurrencyConvertor = new System.Windows.Forms.Button();
            this.txtConvert = new System.Windows.Forms.TextBox();
            this.lblConvert = new System.Windows.Forms.Label();
            this.BtnClose = new System.Windows.Forms.Button();
            this.BtnConvert = new System.Windows.Forms.Button();
            this.cmbCurrency = new System.Windows.Forms.ComboBox();
            this.BtnEqual = new System.Windows.Forms.Button();
            this.BtnDot = new System.Windows.Forms.Button();
            this.BtnZero = new System.Windows.Forms.Button();
            this.BtnMultiply = new System.Windows.Forms.Button();
            this.BtnThree = new System.Windows.Forms.Button();
            this.BtnTwo = new System.Windows.Forms.Button();
            this.Btnone = new System.Windows.Forms.Button();
            this.BtnDivide = new System.Windows.Forms.Button();
            this.BtnSix = new System.Windows.Forms.Button();
            this.BtnFive = new System.Windows.Forms.Button();
            this.BtnFour = new System.Windows.Forms.Button();
            this.BtnMinus = new System.Windows.Forms.Button();
            this.BtnNine = new System.Windows.Forms.Button();
            this.BtnEight = new System.Windows.Forms.Button();
            this.BtnSeven = new System.Windows.Forms.Button();
            this.BtnAdd = new System.Windows.Forms.Button();
            this.BtnClear = new System.Windows.Forms.Button();
            this.BtnBspace = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.lblDisplay = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.standardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.currencyConvertorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.receiptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewOrderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.order_SystemsDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.net_TotalTextBox = new System.Windows.Forms.TextBox();
            this.net_Sub_TotalTextBox = new System.Windows.Forms.TextBox();
            this.taxTextBox = new System.Windows.Forms.TextBox();
            this.lblnettotal = new System.Windows.Forms.Label();
            this.lbltax = new System.Windows.Forms.Label();
            this.lblordersubtotal = new System.Windows.Forms.Label();
            this.order_SystemsTableAdapter = new Exercise.OrdersDataSet1TableAdapters.Order_SystemsTableAdapter();
            this.tableAdapterManager = new Exercise.OrdersDataSet1TableAdapters.TableAdapterManager();
            this.order_SystemsBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.order_SystemsBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.txtReceipt = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.order_SystemsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordersDataSet1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.order_SystemsDataGridView)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.order_SystemsBindingNavigator)).BeginInit();
            this.order_SystemsBindingNavigator.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox1.Controls.Add(this.order_TimeTextBox);
            this.groupBox1.Controls.Add(this.order_DateTextBox);
            this.groupBox1.Controls.Add(this.customer_PhoneTextBox);
            this.groupBox1.Controls.Add(this.customer_NameTextBox);
            this.groupBox1.Controls.Add(this.order_IdTextBox);
            this.groupBox1.Controls.Add(this.lbltime);
            this.groupBox1.Controls.Add(this.lbldate);
            this.groupBox1.Controls.Add(this.lblorder);
            this.groupBox1.Controls.Add(this.lblphone);
            this.groupBox1.Controls.Add(this.lblname);
            this.groupBox1.Location = new System.Drawing.Point(0, 28);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(564, 222);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // order_TimeTextBox
            // 
            this.order_TimeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.order_SystemsBindingSource, "Order_Time", true));
            this.order_TimeTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.order_TimeTextBox.Location = new System.Drawing.Point(432, 99);
            this.order_TimeTextBox.Name = "order_TimeTextBox";
            this.order_TimeTextBox.Size = new System.Drawing.Size(100, 31);
            this.order_TimeTextBox.TabIndex = 10;
            // 
            // order_SystemsBindingSource
            // 
            this.order_SystemsBindingSource.DataMember = "Order_Systems";
            this.order_SystemsBindingSource.DataSource = this.ordersDataSet1;
            // 
            // ordersDataSet1
            // 
            this.ordersDataSet1.DataSetName = "OrdersDataSet1";
            this.ordersDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // order_DateTextBox
            // 
            this.order_DateTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.order_SystemsBindingSource, "Order_Date", true));
            this.order_DateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.order_DateTextBox.Location = new System.Drawing.Point(432, 37);
            this.order_DateTextBox.Name = "order_DateTextBox";
            this.order_DateTextBox.Size = new System.Drawing.Size(100, 31);
            this.order_DateTextBox.TabIndex = 9;
            // 
            // customer_PhoneTextBox
            // 
            this.customer_PhoneTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.order_SystemsBindingSource, "Customer_Phone", true));
            this.customer_PhoneTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customer_PhoneTextBox.Location = new System.Drawing.Point(193, 99);
            this.customer_PhoneTextBox.Name = "customer_PhoneTextBox";
            this.customer_PhoneTextBox.Size = new System.Drawing.Size(100, 31);
            this.customer_PhoneTextBox.TabIndex = 8;
            // 
            // customer_NameTextBox
            // 
            this.customer_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.order_SystemsBindingSource, "Customer_Name", true));
            this.customer_NameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customer_NameTextBox.Location = new System.Drawing.Point(185, 36);
            this.customer_NameTextBox.Name = "customer_NameTextBox";
            this.customer_NameTextBox.Size = new System.Drawing.Size(100, 31);
            this.customer_NameTextBox.TabIndex = 7;
            // 
            // order_IdTextBox
            // 
            this.order_IdTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.order_SystemsBindingSource, "Order_Id", true));
            this.order_IdTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.order_IdTextBox.Location = new System.Drawing.Point(117, 170);
            this.order_IdTextBox.Name = "order_IdTextBox";
            this.order_IdTextBox.Size = new System.Drawing.Size(100, 31);
            this.order_IdTextBox.TabIndex = 6;
            // 
            // lbltime
            // 
            this.lbltime.AutoSize = true;
            this.lbltime.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltime.Location = new System.Drawing.Point(299, 94);
            this.lbltime.Name = "lbltime";
            this.lbltime.Size = new System.Drawing.Size(136, 25);
            this.lbltime.TabIndex = 4;
            this.lbltime.Text = "Order Time:";
            // 
            // lbldate
            // 
            this.lbldate.AutoSize = true;
            this.lbldate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldate.Location = new System.Drawing.Point(301, 31);
            this.lbldate.Name = "lbldate";
            this.lbldate.Size = new System.Drawing.Size(134, 25);
            this.lbldate.TabIndex = 3;
            this.lbldate.Text = "Order Date:";
            // 
            // lblorder
            // 
            this.lblorder.AutoSize = true;
            this.lblorder.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblorder.Location = new System.Drawing.Point(6, 164);
            this.lblorder.Name = "lblorder";
            this.lblorder.Size = new System.Drawing.Size(114, 25);
            this.lblorder.TabIndex = 2;
            this.lblorder.Text = "Order No:";
            // 
            // lblphone
            // 
            this.lblphone.AutoSize = true;
            this.lblphone.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblphone.Location = new System.Drawing.Point(6, 94);
            this.lblphone.Name = "lblphone";
            this.lblphone.Size = new System.Drawing.Size(193, 25);
            this.lblphone.TabIndex = 1;
            this.lblphone.Text = "Customer Phone:";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.Location = new System.Drawing.Point(6, 31);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(186, 25);
            this.lblname.TabIndex = 0;
            this.lblname.Text = "Customer Name:";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox2.Controls.Add(this.BtnFavorites);
            this.groupBox2.Controls.Add(this.BtnOrder);
            this.groupBox2.Controls.Add(this.BtnReceipt);
            this.groupBox2.Controls.Add(this.BtnCalculator);
            this.groupBox2.Controls.Add(this.BtnSave);
            this.groupBox2.Controls.Add(this.BtnReset);
            this.groupBox2.Controls.Add(this.BtnTotal);
            this.groupBox2.Controls.Add(this.sub_Total3TextBox);
            this.groupBox2.Controls.Add(this.sub_Total2TextBox);
            this.groupBox2.Controls.Add(this.sub_Total1TextBox);
            this.groupBox2.Controls.Add(this.unit_Price3TextBox);
            this.groupBox2.Controls.Add(this.unit_Price2TextBox);
            this.groupBox2.Controls.Add(this.unit_Price1TextBox);
            this.groupBox2.Controls.Add(this.qty3TextBox);
            this.groupBox2.Controls.Add(this.qty2TextBox);
            this.groupBox2.Controls.Add(this.qty1TextBox);
            this.groupBox2.Controls.Add(this.lblotherfoods);
            this.groupBox2.Controls.Add(this.lblidly);
            this.groupBox2.Controls.Add(this.lbldosa);
            this.groupBox2.Controls.Add(this.lblsubtotal);
            this.groupBox2.Controls.Add(this.lblunitprice);
            this.groupBox2.Controls.Add(this.lblqty);
            this.groupBox2.Controls.Add(this.lblfoods);
            this.groupBox2.Location = new System.Drawing.Point(0, 256);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(557, 393);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "groupBox2";
            // 
            // BtnFavorites
            // 
            this.BtnFavorites.Location = new System.Drawing.Point(455, 316);
            this.BtnFavorites.Name = "BtnFavorites";
            this.BtnFavorites.Size = new System.Drawing.Size(85, 44);
            this.BtnFavorites.TabIndex = 40;
            this.BtnFavorites.Text = "Add To Favorites";
            this.BtnFavorites.UseVisualStyleBackColor = true;
            this.BtnFavorites.Click += new System.EventHandler(this.BtnFavorites_Click);
            // 
            // BtnOrder
            // 
            this.BtnOrder.Location = new System.Drawing.Point(383, 316);
            this.BtnOrder.Name = "BtnOrder";
            this.BtnOrder.Size = new System.Drawing.Size(66, 44);
            this.BtnOrder.TabIndex = 39;
            this.BtnOrder.Text = "Order";
            this.BtnOrder.UseVisualStyleBackColor = true;
            this.BtnOrder.Click += new System.EventHandler(this.BtnOrder_Click);
            // 
            // BtnReceipt
            // 
            this.BtnReceipt.Location = new System.Drawing.Point(311, 316);
            this.BtnReceipt.Name = "BtnReceipt";
            this.BtnReceipt.Size = new System.Drawing.Size(66, 44);
            this.BtnReceipt.TabIndex = 38;
            this.BtnReceipt.Text = "Receipt";
            this.BtnReceipt.UseVisualStyleBackColor = true;
            this.BtnReceipt.Click += new System.EventHandler(this.BtnReceipt_Click);
            // 
            // BtnCalculator
            // 
            this.BtnCalculator.Location = new System.Drawing.Point(233, 316);
            this.BtnCalculator.Name = "BtnCalculator";
            this.BtnCalculator.Size = new System.Drawing.Size(72, 44);
            this.BtnCalculator.TabIndex = 37;
            this.BtnCalculator.Text = "Calculator";
            this.BtnCalculator.UseVisualStyleBackColor = true;
            this.BtnCalculator.Click += new System.EventHandler(this.BtnCalculator_Click);
            // 
            // BtnSave
            // 
            this.BtnSave.Location = new System.Drawing.Point(162, 316);
            this.BtnSave.Name = "BtnSave";
            this.BtnSave.Size = new System.Drawing.Size(65, 44);
            this.BtnSave.TabIndex = 36;
            this.BtnSave.Text = "Save";
            this.BtnSave.UseVisualStyleBackColor = true;
            this.BtnSave.Click += new System.EventHandler(this.button3_Click);
            // 
            // BtnReset
            // 
            this.BtnReset.Location = new System.Drawing.Point(88, 316);
            this.BtnReset.Name = "BtnReset";
            this.BtnReset.Size = new System.Drawing.Size(68, 44);
            this.BtnReset.TabIndex = 35;
            this.BtnReset.Text = "Reset";
            this.BtnReset.UseVisualStyleBackColor = true;
            this.BtnReset.Click += new System.EventHandler(this.BtnReset_Click);
            // 
            // BtnTotal
            // 
            this.BtnTotal.Location = new System.Drawing.Point(6, 316);
            this.BtnTotal.Name = "BtnTotal";
            this.BtnTotal.Size = new System.Drawing.Size(76, 44);
            this.BtnTotal.TabIndex = 34;
            this.BtnTotal.Text = "Total";
            this.BtnTotal.UseVisualStyleBackColor = true;
            this.BtnTotal.Click += new System.EventHandler(this.BtnTotal_Click);
            // 
            // sub_Total3TextBox
            // 
            this.sub_Total3TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.order_SystemsBindingSource, "Sub_Total3", true));
            this.sub_Total3TextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sub_Total3TextBox.Location = new System.Drawing.Point(432, 253);
            this.sub_Total3TextBox.Name = "sub_Total3TextBox";
            this.sub_Total3TextBox.Size = new System.Drawing.Size(100, 31);
            this.sub_Total3TextBox.TabIndex = 16;
            // 
            // sub_Total2TextBox
            // 
            this.sub_Total2TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.order_SystemsBindingSource, "Sub_Total2", true));
            this.sub_Total2TextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sub_Total2TextBox.Location = new System.Drawing.Point(432, 181);
            this.sub_Total2TextBox.Name = "sub_Total2TextBox";
            this.sub_Total2TextBox.Size = new System.Drawing.Size(100, 31);
            this.sub_Total2TextBox.TabIndex = 15;
            // 
            // sub_Total1TextBox
            // 
            this.sub_Total1TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.order_SystemsBindingSource, "Sub_Total1", true));
            this.sub_Total1TextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sub_Total1TextBox.Location = new System.Drawing.Point(432, 113);
            this.sub_Total1TextBox.Name = "sub_Total1TextBox";
            this.sub_Total1TextBox.Size = new System.Drawing.Size(100, 31);
            this.sub_Total1TextBox.TabIndex = 14;
            // 
            // unit_Price3TextBox
            // 
            this.unit_Price3TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.order_SystemsBindingSource, "Unit_Price3", true));
            this.unit_Price3TextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.unit_Price3TextBox.Location = new System.Drawing.Point(284, 253);
            this.unit_Price3TextBox.Name = "unit_Price3TextBox";
            this.unit_Price3TextBox.Size = new System.Drawing.Size(100, 31);
            this.unit_Price3TextBox.TabIndex = 13;
            // 
            // unit_Price2TextBox
            // 
            this.unit_Price2TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.order_SystemsBindingSource, "Unit_Price2", true));
            this.unit_Price2TextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.unit_Price2TextBox.Location = new System.Drawing.Point(284, 181);
            this.unit_Price2TextBox.Name = "unit_Price2TextBox";
            this.unit_Price2TextBox.Size = new System.Drawing.Size(100, 31);
            this.unit_Price2TextBox.TabIndex = 12;
            // 
            // unit_Price1TextBox
            // 
            this.unit_Price1TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.order_SystemsBindingSource, "Unit_Price1", true));
            this.unit_Price1TextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.unit_Price1TextBox.Location = new System.Drawing.Point(284, 113);
            this.unit_Price1TextBox.Name = "unit_Price1TextBox";
            this.unit_Price1TextBox.Size = new System.Drawing.Size(100, 31);
            this.unit_Price1TextBox.TabIndex = 11;
            this.unit_Price1TextBox.TextChanged += new System.EventHandler(this.unit_Price1TextBox_TextChanged);
            // 
            // qty3TextBox
            // 
            this.qty3TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.order_SystemsBindingSource, "Qty3", true));
            this.qty3TextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qty3TextBox.Location = new System.Drawing.Point(151, 253);
            this.qty3TextBox.Name = "qty3TextBox";
            this.qty3TextBox.Size = new System.Drawing.Size(100, 31);
            this.qty3TextBox.TabIndex = 10;
            // 
            // qty2TextBox
            // 
            this.qty2TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.order_SystemsBindingSource, "Qty2", true));
            this.qty2TextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qty2TextBox.Location = new System.Drawing.Point(151, 181);
            this.qty2TextBox.Name = "qty2TextBox";
            this.qty2TextBox.Size = new System.Drawing.Size(100, 31);
            this.qty2TextBox.TabIndex = 9;
            // 
            // qty1TextBox
            // 
            this.qty1TextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.order_SystemsBindingSource, "Qty1", true));
            this.qty1TextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qty1TextBox.Location = new System.Drawing.Point(151, 114);
            this.qty1TextBox.Name = "qty1TextBox";
            this.qty1TextBox.Size = new System.Drawing.Size(100, 31);
            this.qty1TextBox.TabIndex = 8;
            // 
            // lblotherfoods
            // 
            this.lblotherfoods.AutoSize = true;
            this.lblotherfoods.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblotherfoods.Location = new System.Drawing.Point(6, 247);
            this.lblotherfoods.Name = "lblotherfoods";
            this.lblotherfoods.Size = new System.Drawing.Size(142, 25);
            this.lblotherfoods.TabIndex = 7;
            this.lblotherfoods.Text = "Other Foods";
            // 
            // lblidly
            // 
            this.lblidly.AutoSize = true;
            this.lblidly.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblidly.Location = new System.Drawing.Point(16, 175);
            this.lblidly.Name = "lblidly";
            this.lblidly.Size = new System.Drawing.Size(49, 25);
            this.lblidly.TabIndex = 6;
            this.lblidly.Text = "Idly";
            // 
            // lbldosa
            // 
            this.lbldosa.AutoSize = true;
            this.lbldosa.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldosa.Location = new System.Drawing.Point(16, 108);
            this.lbldosa.Name = "lbldosa";
            this.lbldosa.Size = new System.Drawing.Size(66, 25);
            this.lbldosa.TabIndex = 5;
            this.lbldosa.Text = "Dosa";
            // 
            // lblsubtotal
            // 
            this.lblsubtotal.AutoSize = true;
            this.lblsubtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsubtotal.Location = new System.Drawing.Point(427, 40);
            this.lblsubtotal.Name = "lblsubtotal";
            this.lblsubtotal.Size = new System.Drawing.Size(113, 25);
            this.lblsubtotal.TabIndex = 4;
            this.lblsubtotal.Text = "Sub Total";
            // 
            // lblunitprice
            // 
            this.lblunitprice.AutoSize = true;
            this.lblunitprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblunitprice.Location = new System.Drawing.Point(279, 40);
            this.lblunitprice.Name = "lblunitprice";
            this.lblunitprice.Size = new System.Drawing.Size(115, 25);
            this.lblunitprice.TabIndex = 3;
            this.lblunitprice.Text = "Unit Price";
            // 
            // lblqty
            // 
            this.lblqty.AutoSize = true;
            this.lblqty.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblqty.Location = new System.Drawing.Point(180, 40);
            this.lblqty.Name = "lblqty";
            this.lblqty.Size = new System.Drawing.Size(48, 25);
            this.lblqty.TabIndex = 2;
            this.lblqty.Text = "Qty";
            // 
            // lblfoods
            // 
            this.lblfoods.AutoSize = true;
            this.lblfoods.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfoods.Location = new System.Drawing.Point(16, 40);
            this.lblfoods.Name = "lblfoods";
            this.lblfoods.Size = new System.Drawing.Size(77, 25);
            this.lblfoods.TabIndex = 1;
            this.lblfoods.Text = "Foods";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox3.Controls.Add(this.tabControl1);
            this.groupBox3.Location = new System.Drawing.Point(564, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(756, 424);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "groupBox3";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(6, 19);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(750, 399);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lblShowCal);
            this.tabPage1.Controls.Add(this.BtnCurrencyConvertor);
            this.tabPage1.Controls.Add(this.txtConvert);
            this.tabPage1.Controls.Add(this.lblConvert);
            this.tabPage1.Controls.Add(this.BtnClose);
            this.tabPage1.Controls.Add(this.BtnConvert);
            this.tabPage1.Controls.Add(this.cmbCurrency);
            this.tabPage1.Controls.Add(this.BtnEqual);
            this.tabPage1.Controls.Add(this.BtnDot);
            this.tabPage1.Controls.Add(this.BtnZero);
            this.tabPage1.Controls.Add(this.BtnMultiply);
            this.tabPage1.Controls.Add(this.BtnThree);
            this.tabPage1.Controls.Add(this.BtnTwo);
            this.tabPage1.Controls.Add(this.Btnone);
            this.tabPage1.Controls.Add(this.BtnDivide);
            this.tabPage1.Controls.Add(this.BtnSix);
            this.tabPage1.Controls.Add(this.BtnFive);
            this.tabPage1.Controls.Add(this.BtnFour);
            this.tabPage1.Controls.Add(this.BtnMinus);
            this.tabPage1.Controls.Add(this.BtnNine);
            this.tabPage1.Controls.Add(this.BtnEight);
            this.tabPage1.Controls.Add(this.BtnSeven);
            this.tabPage1.Controls.Add(this.BtnAdd);
            this.tabPage1.Controls.Add(this.BtnClear);
            this.tabPage1.Controls.Add(this.BtnBspace);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.lblDisplay);
            this.tabPage1.Controls.Add(this.menuStrip1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(742, 373);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Calculator";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // lblShowCal
            // 
            this.lblShowCal.Location = new System.Drawing.Point(12, 37);
            this.lblShowCal.Name = "lblShowCal";
            this.lblShowCal.Size = new System.Drawing.Size(100, 23);
            this.lblShowCal.TabIndex = 31;
            // 
            // BtnCurrencyConvertor
            // 
            this.BtnCurrencyConvertor.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCurrencyConvertor.Location = new System.Drawing.Point(337, 0);
            this.BtnCurrencyConvertor.Name = "BtnCurrencyConvertor";
            this.BtnCurrencyConvertor.Size = new System.Drawing.Size(230, 367);
            this.BtnCurrencyConvertor.TabIndex = 30;
            this.BtnCurrencyConvertor.Text = "Currency Convertor";
            this.BtnCurrencyConvertor.UseVisualStyleBackColor = true;
            this.BtnCurrencyConvertor.Click += new System.EventHandler(this.BtnCurrencyConvertor_Click);
            // 
            // txtConvert
            // 
            this.txtConvert.Location = new System.Drawing.Point(340, 81);
            this.txtConvert.Name = "txtConvert";
            this.txtConvert.Size = new System.Drawing.Size(218, 20);
            this.txtConvert.TabIndex = 29;
            // 
            // lblConvert
            // 
            this.lblConvert.Location = new System.Drawing.Point(334, 156);
            this.lblConvert.Name = "lblConvert";
            this.lblConvert.Size = new System.Drawing.Size(224, 84);
            this.lblConvert.TabIndex = 28;
            // 
            // BtnClose
            // 
            this.BtnClose.Location = new System.Drawing.Point(455, 307);
            this.BtnClose.Name = "BtnClose";
            this.BtnClose.Size = new System.Drawing.Size(103, 46);
            this.BtnClose.TabIndex = 27;
            this.BtnClose.Text = "Close";
            this.BtnClose.UseVisualStyleBackColor = true;
            // 
            // BtnConvert
            // 
            this.BtnConvert.Location = new System.Drawing.Point(337, 307);
            this.BtnConvert.Name = "BtnConvert";
            this.BtnConvert.Size = new System.Drawing.Size(103, 46);
            this.BtnConvert.TabIndex = 26;
            this.BtnConvert.Text = "Convert";
            this.BtnConvert.UseVisualStyleBackColor = true;
            this.BtnConvert.Click += new System.EventHandler(this.BtnConvert_Click);
            // 
            // cmbCurrency
            // 
            this.cmbCurrency.FormattingEnabled = true;
            this.cmbCurrency.Location = new System.Drawing.Point(337, 21);
            this.cmbCurrency.Name = "cmbCurrency";
            this.cmbCurrency.Size = new System.Drawing.Size(221, 21);
            this.cmbCurrency.TabIndex = 25;
            // 
            // BtnEqual
            // 
            this.BtnEqual.Location = new System.Drawing.Point(121, 307);
            this.BtnEqual.Name = "BtnEqual";
            this.BtnEqual.Size = new System.Drawing.Size(106, 55);
            this.BtnEqual.TabIndex = 24;
            this.BtnEqual.Text = "=";
            this.BtnEqual.UseVisualStyleBackColor = true;
            this.BtnEqual.Click += new System.EventHandler(this.BtnEqual_Click);
            // 
            // BtnDot
            // 
            this.BtnDot.Location = new System.Drawing.Point(65, 307);
            this.BtnDot.Name = "BtnDot";
            this.BtnDot.Size = new System.Drawing.Size(50, 55);
            this.BtnDot.TabIndex = 23;
            this.BtnDot.Text = ".";
            this.BtnDot.UseVisualStyleBackColor = true;
            this.BtnDot.Click += new System.EventHandler(this.BtnDot_Click);
            // 
            // BtnZero
            // 
            this.BtnZero.Location = new System.Drawing.Point(9, 307);
            this.BtnZero.Name = "BtnZero";
            this.BtnZero.Size = new System.Drawing.Size(50, 55);
            this.BtnZero.TabIndex = 22;
            this.BtnZero.Text = "0";
            this.BtnZero.UseVisualStyleBackColor = true;
            this.BtnZero.Click += new System.EventHandler(this.Button_Click);
            // 
            // BtnMultiply
            // 
            this.BtnMultiply.Location = new System.Drawing.Point(177, 246);
            this.BtnMultiply.Name = "BtnMultiply";
            this.BtnMultiply.Size = new System.Drawing.Size(50, 55);
            this.BtnMultiply.TabIndex = 21;
            this.BtnMultiply.Text = "*";
            this.BtnMultiply.UseVisualStyleBackColor = true;
            this.BtnMultiply.Click += new System.EventHandler(this.Cal_Operators);
            // 
            // BtnThree
            // 
            this.BtnThree.Location = new System.Drawing.Point(121, 246);
            this.BtnThree.Name = "BtnThree";
            this.BtnThree.Size = new System.Drawing.Size(50, 55);
            this.BtnThree.TabIndex = 20;
            this.BtnThree.Text = "3";
            this.BtnThree.UseVisualStyleBackColor = true;
            this.BtnThree.Click += new System.EventHandler(this.Button_Click);
            // 
            // BtnTwo
            // 
            this.BtnTwo.Location = new System.Drawing.Point(65, 246);
            this.BtnTwo.Name = "BtnTwo";
            this.BtnTwo.Size = new System.Drawing.Size(50, 55);
            this.BtnTwo.TabIndex = 19;
            this.BtnTwo.Text = "2";
            this.BtnTwo.UseVisualStyleBackColor = true;
            this.BtnTwo.Click += new System.EventHandler(this.Button_Click);
            // 
            // Btnone
            // 
            this.Btnone.Location = new System.Drawing.Point(9, 246);
            this.Btnone.Name = "Btnone";
            this.Btnone.Size = new System.Drawing.Size(50, 55);
            this.Btnone.TabIndex = 18;
            this.Btnone.Text = "1";
            this.Btnone.UseVisualStyleBackColor = true;
            this.Btnone.Click += new System.EventHandler(this.Button_Click);
            // 
            // BtnDivide
            // 
            this.BtnDivide.Location = new System.Drawing.Point(177, 185);
            this.BtnDivide.Name = "BtnDivide";
            this.BtnDivide.Size = new System.Drawing.Size(50, 55);
            this.BtnDivide.TabIndex = 17;
            this.BtnDivide.Text = "/";
            this.BtnDivide.UseVisualStyleBackColor = true;
            this.BtnDivide.Click += new System.EventHandler(this.Cal_Operators);
            // 
            // BtnSix
            // 
            this.BtnSix.Location = new System.Drawing.Point(121, 185);
            this.BtnSix.Name = "BtnSix";
            this.BtnSix.Size = new System.Drawing.Size(50, 55);
            this.BtnSix.TabIndex = 16;
            this.BtnSix.Text = "6";
            this.BtnSix.UseVisualStyleBackColor = true;
            this.BtnSix.Click += new System.EventHandler(this.Button_Click);
            // 
            // BtnFive
            // 
            this.BtnFive.Location = new System.Drawing.Point(65, 185);
            this.BtnFive.Name = "BtnFive";
            this.BtnFive.Size = new System.Drawing.Size(50, 55);
            this.BtnFive.TabIndex = 15;
            this.BtnFive.Text = "5";
            this.BtnFive.UseVisualStyleBackColor = true;
            this.BtnFive.Click += new System.EventHandler(this.Button_Click);
            // 
            // BtnFour
            // 
            this.BtnFour.Location = new System.Drawing.Point(9, 185);
            this.BtnFour.Name = "BtnFour";
            this.BtnFour.Size = new System.Drawing.Size(50, 55);
            this.BtnFour.TabIndex = 14;
            this.BtnFour.Text = "4";
            this.BtnFour.UseVisualStyleBackColor = true;
            this.BtnFour.Click += new System.EventHandler(this.Button_Click);
            // 
            // BtnMinus
            // 
            this.BtnMinus.Location = new System.Drawing.Point(177, 124);
            this.BtnMinus.Name = "BtnMinus";
            this.BtnMinus.Size = new System.Drawing.Size(47, 55);
            this.BtnMinus.TabIndex = 13;
            this.BtnMinus.Text = "-";
            this.BtnMinus.UseVisualStyleBackColor = true;
            this.BtnMinus.Click += new System.EventHandler(this.Cal_Operators);
            // 
            // BtnNine
            // 
            this.BtnNine.Location = new System.Drawing.Point(121, 124);
            this.BtnNine.Name = "BtnNine";
            this.BtnNine.Size = new System.Drawing.Size(47, 55);
            this.BtnNine.TabIndex = 12;
            this.BtnNine.Text = "9";
            this.BtnNine.UseVisualStyleBackColor = true;
            this.BtnNine.Click += new System.EventHandler(this.Button_Click);
            // 
            // BtnEight
            // 
            this.BtnEight.Location = new System.Drawing.Point(65, 124);
            this.BtnEight.Name = "BtnEight";
            this.BtnEight.Size = new System.Drawing.Size(47, 55);
            this.BtnEight.TabIndex = 11;
            this.BtnEight.Text = "8";
            this.BtnEight.UseVisualStyleBackColor = true;
            this.BtnEight.Click += new System.EventHandler(this.Button_Click);
            // 
            // BtnSeven
            // 
            this.BtnSeven.Location = new System.Drawing.Point(9, 124);
            this.BtnSeven.Name = "BtnSeven";
            this.BtnSeven.Size = new System.Drawing.Size(47, 55);
            this.BtnSeven.TabIndex = 10;
            this.BtnSeven.Text = "7";
            this.BtnSeven.UseVisualStyleBackColor = true;
            this.BtnSeven.Click += new System.EventHandler(this.Button_Click);
            // 
            // BtnAdd
            // 
            this.BtnAdd.Location = new System.Drawing.Point(174, 63);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(50, 55);
            this.BtnAdd.TabIndex = 8;
            this.BtnAdd.Text = "+";
            this.BtnAdd.UseVisualStyleBackColor = true;
            this.BtnAdd.Click += new System.EventHandler(this.Cal_Operators);
            // 
            // BtnClear
            // 
            this.BtnClear.Location = new System.Drawing.Point(118, 63);
            this.BtnClear.Name = "BtnClear";
            this.BtnClear.Size = new System.Drawing.Size(50, 55);
            this.BtnClear.TabIndex = 7;
            this.BtnClear.Text = "c";
            this.BtnClear.UseVisualStyleBackColor = true;
            this.BtnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // 
            // BtnBspace
            // 
            this.BtnBspace.Location = new System.Drawing.Point(6, 63);
            this.BtnBspace.Name = "BtnBspace";
            this.BtnBspace.Size = new System.Drawing.Size(109, 55);
            this.BtnBspace.TabIndex = 6;
            this.BtnBspace.Text = "<-";
            this.BtnBspace.UseVisualStyleBackColor = true;
            this.BtnBspace.Click += new System.EventHandler(this.BtnBspace_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(15, 12);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(0, 13);
            this.label17.TabIndex = 5;
            // 
            // lblDisplay
            // 
            this.lblDisplay.BackColor = System.Drawing.Color.White;
            this.lblDisplay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDisplay.Location = new System.Drawing.Point(3, 27);
            this.lblDisplay.Name = "lblDisplay";
            this.lblDisplay.Size = new System.Drawing.Size(221, 33);
            this.lblDisplay.TabIndex = 0;
            this.lblDisplay.Text = "0";
            this.lblDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.editToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(3, 3);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(736, 24);
            this.menuStrip1.TabIndex = 32;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.standardToolStripMenuItem,
            this.currencyConvertorToolStripMenuItem,
            this.receiptToolStripMenuItem,
            this.viewOrderToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(44, 20);
            this.toolStripMenuItem1.Text = "View";
            // 
            // standardToolStripMenuItem
            // 
            this.standardToolStripMenuItem.Name = "standardToolStripMenuItem";
            this.standardToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.standardToolStripMenuItem.Text = "Standard";
            this.standardToolStripMenuItem.Click += new System.EventHandler(this.standardToolStripMenuItem_Click);
            // 
            // currencyConvertorToolStripMenuItem
            // 
            this.currencyConvertorToolStripMenuItem.Name = "currencyConvertorToolStripMenuItem";
            this.currencyConvertorToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.currencyConvertorToolStripMenuItem.Text = "Currency_Convertor";
            this.currencyConvertorToolStripMenuItem.Click += new System.EventHandler(this.currencyConvertorToolStripMenuItem_Click);
            // 
            // receiptToolStripMenuItem
            // 
            this.receiptToolStripMenuItem.Name = "receiptToolStripMenuItem";
            this.receiptToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.receiptToolStripMenuItem.Text = "Receipt";
            this.receiptToolStripMenuItem.Click += new System.EventHandler(this.receiptToolStripMenuItem_Click);
            // 
            // viewOrderToolStripMenuItem
            // 
            this.viewOrderToolStripMenuItem.Name = "viewOrderToolStripMenuItem";
            this.viewOrderToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.viewOrderToolStripMenuItem.Text = "View_Order";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.txtReceipt);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(742, 373);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Receipt";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.order_SystemsDataGridView);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(742, 373);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Orders";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // order_SystemsDataGridView
            // 
            this.order_SystemsDataGridView.AutoGenerateColumns = false;
            this.order_SystemsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.order_SystemsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20});
            this.order_SystemsDataGridView.DataSource = this.order_SystemsBindingSource;
            this.order_SystemsDataGridView.Location = new System.Drawing.Point(0, 12);
            this.order_SystemsDataGridView.Name = "order_SystemsDataGridView";
            this.order_SystemsDataGridView.Size = new System.Drawing.Size(740, 355);
            this.order_SystemsDataGridView.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Order_Id";
            this.dataGridViewTextBoxColumn1.HeaderText = "Order_Id";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Customer_Name";
            this.dataGridViewTextBoxColumn2.HeaderText = "Customer_Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Customer_Phone";
            this.dataGridViewTextBoxColumn3.HeaderText = "Customer_Phone";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Order_Date";
            this.dataGridViewTextBoxColumn4.HeaderText = "Order_Date";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Order_Time";
            this.dataGridViewTextBoxColumn5.HeaderText = "Order_Time";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Dosa";
            this.dataGridViewTextBoxColumn6.HeaderText = "Dosa";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Idly";
            this.dataGridViewTextBoxColumn7.HeaderText = "Idly";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Other_Foods";
            this.dataGridViewTextBoxColumn8.HeaderText = "Other_Foods";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Qty1";
            this.dataGridViewTextBoxColumn9.HeaderText = "Qty1";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Qty2";
            this.dataGridViewTextBoxColumn10.HeaderText = "Qty2";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Qty3";
            this.dataGridViewTextBoxColumn11.HeaderText = "Qty3";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Unit_Price1";
            this.dataGridViewTextBoxColumn12.HeaderText = "Unit_Price1";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "Unit_Price2";
            this.dataGridViewTextBoxColumn13.HeaderText = "Unit_Price2";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "Unit_Price3";
            this.dataGridViewTextBoxColumn14.HeaderText = "Unit_Price3";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "Sub_Total1";
            this.dataGridViewTextBoxColumn15.HeaderText = "Sub_Total1";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "Sub_Total2";
            this.dataGridViewTextBoxColumn16.HeaderText = "Sub_Total2";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "Sub_Total3";
            this.dataGridViewTextBoxColumn17.HeaderText = "Sub_Total3";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "Tax";
            this.dataGridViewTextBoxColumn18.HeaderText = "Tax";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "Net_Sub_Total";
            this.dataGridViewTextBoxColumn19.HeaderText = "Net_Sub_Total";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "Net_Total";
            this.dataGridViewTextBoxColumn20.HeaderText = "Net_Total";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox4.Controls.Add(this.net_TotalTextBox);
            this.groupBox4.Controls.Add(this.net_Sub_TotalTextBox);
            this.groupBox4.Controls.Add(this.taxTextBox);
            this.groupBox4.Controls.Add(this.lblnettotal);
            this.groupBox4.Controls.Add(this.lbltax);
            this.groupBox4.Controls.Add(this.lblordersubtotal);
            this.groupBox4.Location = new System.Drawing.Point(564, 442);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(659, 207);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "groupBox4";
            // 
            // net_TotalTextBox
            // 
            this.net_TotalTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.order_SystemsBindingSource, "Net_Total", true));
            this.net_TotalTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.net_TotalTextBox.Location = new System.Drawing.Point(87, 155);
            this.net_TotalTextBox.Name = "net_TotalTextBox";
            this.net_TotalTextBox.Size = new System.Drawing.Size(100, 31);
            this.net_TotalTextBox.TabIndex = 6;
            // 
            // net_Sub_TotalTextBox
            // 
            this.net_Sub_TotalTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.order_SystemsBindingSource, "Net_Sub_Total", true));
            this.net_Sub_TotalTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.net_Sub_TotalTextBox.Location = new System.Drawing.Point(184, 38);
            this.net_Sub_TotalTextBox.Name = "net_Sub_TotalTextBox";
            this.net_Sub_TotalTextBox.Size = new System.Drawing.Size(100, 31);
            this.net_Sub_TotalTextBox.TabIndex = 5;
            // 
            // taxTextBox
            // 
            this.taxTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.order_SystemsBindingSource, "Tax", true));
            this.taxTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.taxTextBox.Location = new System.Drawing.Point(87, 91);
            this.taxTextBox.Name = "taxTextBox";
            this.taxTextBox.Size = new System.Drawing.Size(100, 31);
            this.taxTextBox.TabIndex = 4;
            // 
            // lblnettotal
            // 
            this.lblnettotal.AutoSize = true;
            this.lblnettotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnettotal.Location = new System.Drawing.Point(14, 149);
            this.lblnettotal.Name = "lblnettotal";
            this.lblnettotal.Size = new System.Drawing.Size(65, 25);
            this.lblnettotal.TabIndex = 3;
            this.lblnettotal.Text = "Total";
            // 
            // lbltax
            // 
            this.lbltax.AutoSize = true;
            this.lbltax.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltax.Location = new System.Drawing.Point(14, 85);
            this.lbltax.Name = "lbltax";
            this.lbltax.Size = new System.Drawing.Size(51, 25);
            this.lbltax.TabIndex = 2;
            this.lbltax.Text = "Tax";
            // 
            // lblordersubtotal
            // 
            this.lblordersubtotal.AutoSize = true;
            this.lblordersubtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblordersubtotal.Location = new System.Drawing.Point(8, 32);
            this.lblordersubtotal.Name = "lblordersubtotal";
            this.lblordersubtotal.Size = new System.Drawing.Size(179, 25);
            this.lblordersubtotal.TabIndex = 1;
            this.lblordersubtotal.Text = "Order Sub Total";
            // 
            // order_SystemsTableAdapter
            // 
            this.order_SystemsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Order_SystemsTableAdapter = this.order_SystemsTableAdapter;
            this.tableAdapterManager.UpdateOrder = Exercise.OrdersDataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // order_SystemsBindingNavigator
            // 
            this.order_SystemsBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.order_SystemsBindingNavigator.BindingSource = this.order_SystemsBindingSource;
            this.order_SystemsBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.order_SystemsBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.order_SystemsBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.order_SystemsBindingNavigatorSaveItem});
            this.order_SystemsBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.order_SystemsBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.order_SystemsBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.order_SystemsBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.order_SystemsBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.order_SystemsBindingNavigator.Name = "order_SystemsBindingNavigator";
            this.order_SystemsBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.order_SystemsBindingNavigator.Size = new System.Drawing.Size(1320, 25);
            this.order_SystemsBindingNavigator.TabIndex = 4;
            this.order_SystemsBindingNavigator.Text = "bindingNavigator1";
            this.order_SystemsBindingNavigator.RefreshItems += new System.EventHandler(this.order_SystemsBindingNavigator_RefreshItems);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // order_SystemsBindingNavigatorSaveItem
            // 
            this.order_SystemsBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.order_SystemsBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("order_SystemsBindingNavigatorSaveItem.Image")));
            this.order_SystemsBindingNavigatorSaveItem.Name = "order_SystemsBindingNavigatorSaveItem";
            this.order_SystemsBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.order_SystemsBindingNavigatorSaveItem.Text = "Save Data";
            this.order_SystemsBindingNavigatorSaveItem.Click += new System.EventHandler(this.order_SystemsBindingNavigatorSaveItem_Click);
            // 
            // txtReceipt
            // 
            this.txtReceipt.Location = new System.Drawing.Point(0, 3);
            this.txtReceipt.Multiline = true;
            this.txtReceipt.Name = "txtReceipt";
            this.txtReceipt.Size = new System.Drawing.Size(742, 364);
            this.txtReceipt.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1320, 661);
            this.Controls.Add(this.order_SystemsBindingNavigator);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.order_SystemsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordersDataSet1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.order_SystemsDataGridView)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.order_SystemsBindingNavigator)).EndInit();
            this.order_SystemsBindingNavigator.ResumeLayout(false);
            this.order_SystemsBindingNavigator.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label lbltime;
        private System.Windows.Forms.Label lbldate;
        private System.Windows.Forms.Label lblorder;
        private System.Windows.Forms.Label lblphone;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lblfoods;
        private System.Windows.Forms.Label lblotherfoods;
        private System.Windows.Forms.Label lblidly;
        private System.Windows.Forms.Label lbldosa;
        private System.Windows.Forms.Label lblsubtotal;
        private System.Windows.Forms.Label lblunitprice;
        private System.Windows.Forms.Label lblqty;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button BtnMultiply;
        private System.Windows.Forms.Button BtnThree;
        private System.Windows.Forms.Button BtnTwo;
        private System.Windows.Forms.Button Btnone;
        private System.Windows.Forms.Button BtnDivide;
        private System.Windows.Forms.Button BtnSix;
        private System.Windows.Forms.Button BtnFive;
        private System.Windows.Forms.Button BtnFour;
        private System.Windows.Forms.Button BtnMinus;
        private System.Windows.Forms.Button BtnNine;
        private System.Windows.Forms.Button BtnEight;
        private System.Windows.Forms.Button BtnSeven;
        private System.Windows.Forms.Button BtnAdd;
        private System.Windows.Forms.Button BtnClear;
        private System.Windows.Forms.Button BtnBspace;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lblDisplay;
        private System.Windows.Forms.Label lblnettotal;
        private System.Windows.Forms.Label lbltax;
        private System.Windows.Forms.Label lblordersubtotal;
        private System.Windows.Forms.Button BtnCurrencyConvertor;
        private System.Windows.Forms.TextBox txtConvert;
        private System.Windows.Forms.Label lblConvert;
        private System.Windows.Forms.Button BtnClose;
        private System.Windows.Forms.Button BtnConvert;
        private System.Windows.Forms.ComboBox cmbCurrency;
        private System.Windows.Forms.Button BtnEqual;
        private System.Windows.Forms.Button BtnDot;
        private System.Windows.Forms.Button BtnZero;
        private OrdersDataSet1 ordersDataSet1;
        private System.Windows.Forms.BindingSource order_SystemsBindingSource;
        private OrdersDataSet1TableAdapters.Order_SystemsTableAdapter order_SystemsTableAdapter;
        private OrdersDataSet1TableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator order_SystemsBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton order_SystemsBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox customer_PhoneTextBox;
        private System.Windows.Forms.TextBox customer_NameTextBox;
        private System.Windows.Forms.TextBox order_IdTextBox;
        private System.Windows.Forms.DataGridView order_SystemsDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.TextBox order_TimeTextBox;
        private System.Windows.Forms.TextBox order_DateTextBox;
        private System.Windows.Forms.TextBox unit_Price1TextBox;
        private System.Windows.Forms.TextBox qty3TextBox;
        private System.Windows.Forms.TextBox qty2TextBox;
        private System.Windows.Forms.TextBox qty1TextBox;
        private System.Windows.Forms.TextBox sub_Total3TextBox;
        private System.Windows.Forms.TextBox sub_Total2TextBox;
        private System.Windows.Forms.TextBox sub_Total1TextBox;
        private System.Windows.Forms.TextBox unit_Price3TextBox;
        private System.Windows.Forms.TextBox unit_Price2TextBox;
        private System.Windows.Forms.TextBox net_TotalTextBox;
        private System.Windows.Forms.TextBox net_Sub_TotalTextBox;
        private System.Windows.Forms.TextBox taxTextBox;
        private System.Windows.Forms.Label lblShowCal;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem standardToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem currencyConvertorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem receiptToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewOrderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.Button BtnOrder;
        private System.Windows.Forms.Button BtnReceipt;
        private System.Windows.Forms.Button BtnCalculator;
        private System.Windows.Forms.Button BtnSave;
        private System.Windows.Forms.Button BtnReset;
        private System.Windows.Forms.Button BtnTotal;
        private System.Windows.Forms.Button BtnFavorites;
        private System.Windows.Forms.TextBox txtReceipt;
    }
}

